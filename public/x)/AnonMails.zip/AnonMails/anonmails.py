import tkinter as tk
from tkinter import ttk, messagebox
import requests
import json
import random
import string
import threading
from datetime import datetime
from bs4 import BeautifulSoup
import os
import socks
import socket
from stem import Signal
from stem.control import Controller

class TempMailGenerator:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("AnonMails Generator")
        self.root.geometry("1000x700")
        
        # Initialize variables
        self.current_email = tk.StringVar(value="Email: ")
        self.password_var = tk.StringVar(value="Password: ")
        self.email_password = ""
        self.email_history = []
        
        # Initialize statistics
        self.stats = {
            "total_emails": 0,
            "total_messages": 0,
            "platforms": {}
        }
        
        # Initialize session with cookies
        self.init_session()
        
        # Setup UI first
        self.setup_ui()
        
        # Load saved data after UI is setup
        self.load_email_history()
        self.load_statistics()

    def setup_ui(self):
        # Configure modern colors
        self.bg_color = "#1A1B2E"         # Dark navy background
        self.card_bg = "#242645"          # Slightly lighter navy for cards
        self.accent_color = "#6C5DD3"     # Purple accent
        self.text_color = "#FFFFFF"       # White text
        self.secondary_text = "#8E8EA9"   # Light gray text
        self.error_color = "#FF6B6B"      # Coral red for errors
        self.success_color = "#4CAF50"    # Green for success
        self.hover_color = "#8875FF"      # Lighter purple for hover
        
        # Configure root window
        self.root.configure(bg=self.bg_color)
        
        # Configure styles
        self.style = ttk.Style()
        self.style.configure("Modern.TFrame", background=self.bg_color)
        self.style.configure("Card.TFrame", 
                           background=self.card_bg,
                           borderwidth=0,
                           relief="flat")
        
        # Configure Treeview style for modern look
        self.style.configure("Modern.Treeview",
                           background=self.card_bg,
                           foreground=self.text_color,
                           fieldbackground=self.card_bg,
                           borderwidth=0)
        
        self.style.configure("Modern.Treeview.Heading",
                           background=self.card_bg,
                           foreground=self.text_color,
                           borderwidth=0)
        
        # Custom fonts
        self.title_font = ('Segoe UI', 24, 'bold')
        self.header_font = ('Segoe UI', 16, 'bold')
        self.text_font = ('Segoe UI', 10)
        
        # Main container
        main_frame = ttk.Frame(self.root, style="Modern.TFrame", padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create two columns
        left_column = ttk.Frame(main_frame, style="Modern.TFrame")
        left_column.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        right_column = ttk.Frame(main_frame, style="Modern.TFrame")
        right_column.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Create cards (removed header)
        self.create_email_card(left_column)
        self.create_stats_card(left_column)
        self.create_action_card(left_column)
        self.create_history_card(right_column)
        self.create_inbox_card(right_column)
        
        # Add New Identity button at the bottom
        bottom_frame = ttk.Frame(self.root, style="Modern.TFrame")
        bottom_frame.pack(fill=tk.X, pady=(0, 20), padx=20)
        
        new_identity_btn = tk.Button(bottom_frame,
                                    text="New Identity",
                                    font=self.text_font,
                                    bg=self.accent_color,
                                    fg=self.text_color,
                                    relief=tk.FLAT,
                                    padx=20,
                                    pady=8,
                                    cursor="hand2",
                                    command=self.new_identity)
        new_identity_btn.pack()
        
        # Add hover effect
        new_identity_btn.bind('<Enter>', 
                             lambda e: e.widget.configure(bg=self.hover_color))
        new_identity_btn.bind('<Leave>', 
                             lambda e: e.widget.configure(bg=self.accent_color))

    def create_header(self, parent):
        header_frame = ttk.Frame(parent, style="Modern.TFrame")
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(header_frame,
                text="AnonMail Dashboard",
                font=self.title_font,
                fg=self.text_color,
                bg=self.bg_color).pack(side=tk.LEFT)

    def create_modern_card(self, parent, title):
        card = ttk.Frame(parent, style="Card.TFrame")
        card.pack(fill=tk.X, pady=10, padx=5)
        
        # Increase font size for card titles
        card_label = tk.Label(card,
                             text=title,
                             font=('Segoe UI', 20, 'bold'),  # Increased from 16
                             fg=self.text_color,
                             bg=self.card_bg)
        card_label.pack(anchor=tk.W, pady=(15,10), padx=15)
        
        return card

    def create_email_card(self, parent):
        card = self.create_modern_card(parent, "Current Email")
        
        # Email container
        email_frame = ttk.Frame(card, style="Card.TFrame")
        email_frame.pack(fill=tk.X, pady=5, padx=15)
        
        # Email display
        email_label = tk.Label(email_frame,
                             textvariable=self.current_email,
                             font=self.text_font,
                             fg=self.text_color,
                             bg=self.card_bg)
        email_label.pack(side=tk.LEFT)
        
        # Copy button with modern styling
        copy_btn = tk.Button(email_frame,
                           text="Copy",
                           font=self.text_font,
                           bg=self.accent_color,
                           fg=self.text_color,
                           relief=tk.FLAT,
                           padx=15,
                           pady=5,
                           cursor="hand2",
                           command=lambda: self.copy_to_clipboard(
                               self.current_email.get().replace("Email: ", "")))
        copy_btn.pack(side=tk.RIGHT)
        
        # Password container
        pass_frame = ttk.Frame(card, style="Card.TFrame")
        pass_frame.pack(fill=tk.X, pady=5, padx=15)
        
        # Password display
        pass_label = tk.Label(pass_frame,
                            textvariable=self.password_var,
                            font=self.text_font,
                            fg=self.text_color,
                            bg=self.card_bg)
        pass_label.pack(side=tk.LEFT)
        
        # Copy password button
        copy_pass_btn = tk.Button(pass_frame,
                                text="Copy",
                                font=self.text_font,
                                bg=self.accent_color,
                                fg=self.text_color,
                                relief=tk.FLAT,
                                padx=15,
                                pady=5,
                                cursor="hand2",
                                command=lambda: self.copy_to_clipboard(self.email_password))
        copy_pass_btn.pack(side=tk.RIGHT)
        
        # Add hover effects
        for btn in [copy_btn, copy_pass_btn]:
            btn.bind('<Enter>', 
                    lambda e: e.widget.configure(bg=self.hover_color))
            btn.bind('<Leave>', 
                    lambda e: e.widget.configure(bg=self.accent_color))

    def create_stats_card(self, parent):
        card = self.create_modern_card(parent, "Statistics")
        
        stats_frame = ttk.Frame(card, style="Card.TFrame")
        stats_frame.pack(fill=tk.X, pady=5, padx=15)
        
        # Total Emails stat
        email_stat_frame = ttk.Frame(stats_frame, style="Card.TFrame")
        email_stat_frame.pack(fill=tk.X, pady=2)
        
        tk.Label(email_stat_frame,
                text="Total Emails:",
                font=self.text_font,
                fg=self.secondary_text,
                bg=self.card_bg).pack(side=tk.LEFT)
        
        self.total_emails_label = tk.Label(email_stat_frame,
                                         text=str(self.stats['total_emails']),
                                         font=self.text_font,
                                         fg=self.text_color,
                                         bg=self.card_bg)
        self.total_emails_label.pack(side=tk.RIGHT)
        
        # Total Messages stat
        msg_stat_frame = ttk.Frame(stats_frame, style="Card.TFrame")
        msg_stat_frame.pack(fill=tk.X, pady=2)
        
        tk.Label(msg_stat_frame,
                text="Total Messages:",
                font=self.text_font,
                fg=self.secondary_text,
                bg=self.card_bg).pack(side=tk.LEFT)
        
        self.total_messages_label = tk.Label(msg_stat_frame,
                                           text=str(self.stats['total_messages']),
                                           font=self.text_font,
                                           fg=self.text_color,
                                           bg=self.card_bg)
        self.total_messages_label.pack(side=tk.RIGHT)

    def create_action_card(self, parent):
        card = self.create_modern_card(parent, "Actions")
        
        button_frame = ttk.Frame(card, style="Card.TFrame")
        button_frame.pack(fill=tk.X, pady=5, padx=15)
        
        # Add lifespan selection
        lifespan_frame = ttk.Frame(button_frame, style="Card.TFrame")
        lifespan_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(lifespan_frame,
                text="Email Lifespan (days):",
                font=self.text_font,
                fg=self.text_color,
                bg=self.card_bg).pack(side=tk.LEFT, padx=(0, 10))
        
        # Lifespan dropdown
        self.lifespan_var = tk.StringVar(value="1")
        lifespan_options = ["1", "2", "3", "4", "5", "7", "14", "21", "30", "50"]
        lifespan_menu = ttk.Combobox(lifespan_frame,
                                    textvariable=self.lifespan_var,
                                    values=lifespan_options,
                                    state="readonly",
                                    width=5)
        lifespan_menu.pack(side=tk.LEFT)
        
        # Generate Email button
        new_email_btn = tk.Button(button_frame,
                                 text="New Email",
                                 font=self.text_font,
                                 bg=self.accent_color,
                                 fg=self.text_color,
                                 relief=tk.FLAT,
                                 padx=15,
                                 pady=8,
                                 cursor="hand2",
                                 command=self.generate_email)
        new_email_btn.pack(fill=tk.X, pady=5)
        
        # Check Inbox button
        check_inbox_btn = tk.Button(button_frame,
                                   text="Check Inbox",
                                   font=self.text_font,
                                   bg=self.accent_color,
                                   fg=self.text_color,
                                   relief=tk.FLAT,
                                   padx=15,
                                   pady=8,
                                   cursor="hand2",
                                   command=self.check_inbox)
        check_inbox_btn.pack(fill=tk.X, pady=5)
        
        # Credits section
        credits_frame = ttk.Frame(card, style="Card.TFrame")
        credits_frame.pack(fill=tk.X, pady=(15, 5), padx=15)
        
        tk.Label(credits_frame,
                text="p.to/User/Monero",
                font=('Segoe UI', 9),
                fg=self.secondary_text,
                bg=self.card_bg,
                justify=tk.CENTER).pack(fill=tk.X)
        
        # Add hover effects
        for btn in [new_email_btn, check_inbox_btn]:
            btn.bind('<Enter>', 
                    lambda e: e.widget.configure(bg=self.hover_color))
            btn.bind('<Leave>', 
                    lambda e: e.widget.configure(bg=self.accent_color))
    def create_history_card(self, parent):
        card = self.create_modern_card(parent, "Email History")
        
        history_frame = ttk.Frame(card, style="Card.TFrame")
        history_frame.pack(fill=tk.BOTH, expand=True, pady=5, padx=15)
        
        # Modern styled listbox
        self.history_listbox = tk.Listbox(history_frame,
                                        bg=self.card_bg,
                                        fg=self.text_color,
                                        font=self.text_font,
                                        selectmode=tk.SINGLE,
                                        relief=tk.FLAT,
                                        highlightthickness=0,
                                        selectbackground=self.accent_color)
        self.history_listbox.pack(fill=tk.BOTH, expand=True)
        
        # Delete button
        delete_btn = tk.Button(history_frame,
                              text="Delete",
                              font=self.text_font,
                              bg=self.error_color,
                              fg=self.text_color,
                              relief=tk.FLAT,
                              padx=15,
                              pady=5,
                              cursor="hand2",
                              command=self.delete_selected_email)
        delete_btn.pack(pady=10)
        
        # Bind selection event
        self.history_listbox.bind('<<ListboxSelect>>', self.switch_email)

    def create_inbox_card(self, parent):
        card = self.create_modern_card(parent, "Inbox")
        
        inbox_frame = ttk.Frame(card, style="Card.TFrame")
        inbox_frame.pack(fill=tk.BOTH, expand=True, pady=5, padx=15)
        
        # Create tree frame with scrollbar
        tree_frame = ttk.Frame(inbox_frame, style="Card.TFrame")
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create and configure the treeview
        self.inbox_tree = ttk.Treeview(
            tree_frame,
            columns=("From", "Subject", "Time", "UID"),
            show="headings",
            style="Modern.Treeview",
            height=10
        )
        
        # Configure columns
        self.inbox_tree.heading("From", text="From", anchor=tk.W)
        self.inbox_tree.heading("Subject", text="Subject", anchor=tk.W)
        self.inbox_tree.heading("Time", text="Time", anchor=tk.W)
        self.inbox_tree.heading("UID", text="UID", anchor=tk.W)
        
        self.inbox_tree.column("From", width=150)
        self.inbox_tree.column("Subject", width=250)
        self.inbox_tree.column("Time", width=100)
        self.inbox_tree.column("UID", width=0, stretch=False)
        
        # Configure scrollbar
        scrollbar.config(command=self.inbox_tree.yview)
        self.inbox_tree.configure(yscrollcommand=scrollbar.set)
        
        self.inbox_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Bind double-click event
        self.inbox_tree.bind('<Double-1>', self.view_message)

    def update_history_dropdown(self):
        # Clear existing items
        self.history_listbox.delete(0, tk.END)
        
        # Add emails to listbox
        for item in self.email_history:
            self.history_listbox.insert(0, item["email"])
            
        # Select the most recent email
        if self.email_history:
            self.history_listbox.selection_set(0)

    def switch_email(self, event):
        selection = self.history_listbox.curselection()
        if not selection:
            return
            
        selected_email = self.history_listbox.get(selection[0])
        for item in self.email_history:
            if item["email"] == selected_email:
                self.current_email.set(f"Email: {item['email']}")
                self.password_var.set(f"Password: {item['password']}")
                self.email_password = item['password']
                self.check_inbox()
                break

    def delete_selected_email(self):
        selection = self.history_listbox.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select an email to delete")
            return
            
        selected_email = self.history_listbox.get(selection[0])
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete {selected_email}?"):
            try:
                # Get email without domain and current password
                email_addr = selected_email.split('@')[0]
                password = None
                
                # Find password from history
                for item in self.email_history:
                    if item["email"] == selected_email:
                        password = item["password"]
                        break
                
                if not password:
                    raise Exception("Password not found for selected email")
                
                # Login first
                login_data = {
                    'emailAddr': email_addr,
                    'emailPass': password
                }
                
                # Perform login
                login_response = self.session.post(
                    'https://anonmails.de/inbox.php',
                    data=login_data
                )
                
                if login_response.status_code != 200:
                    raise Exception("Failed to login before deletion")
                
                # Send delete request
                delete_response = self.session.get(
                    'https://anonmails.de/inbox.php?closeAccount=1',
                    headers={
                        'Referer': 'https://anonmails.de/inbox.php?check=1',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    }
                )
                
                if delete_response.status_code == 200:
                    # Remove from history
                    self.email_history = [item for item in self.email_history if item["email"] != selected_email]
                    
                    # Update listbox
                    self.update_history_dropdown()
                    
                    # Save updated history
                    self.save_email_history()
                    
                    # Clear current email if it was the deleted one
                    if self.current_email.get().replace("Email: ", "") == selected_email:
                        self.current_email.set("Email: ")
                        self.password_var.set("Password: ")
                        self.email_password = ""
                        
                    # Clear inbox tree
                    for item in self.inbox_tree.get_children():
                        self.inbox_tree.delete(item)
                        
                    messagebox.showinfo("Success", "Email account deleted successfully")
                else:
                    raise Exception(f"Failed to delete account. Status code: {delete_response.status_code}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete email account: {str(e)}")

    def view_message(self, event):
        selection = self.inbox_tree.selection()
        if not selection:
            return
            
        # Create message window with modern styling
        msg_window = tk.Toplevel(self.root)
        msg_window.title("Message Details")
        msg_window.geometry("600x400")
        msg_window.configure(bg=self.card_bg)
        
        # Get message details including UID
        item = selection[0]
        sender, subject, date, uid = self.inbox_tree.item(item)['values']
        
        # Message content frame
        content_frame = ttk.Frame(msg_window, style="Card.TFrame", padding=15)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header information
        tk.Label(content_frame,
                text=f"From: {sender}",
                font=self.text_font,
                fg=self.text_color,
                bg=self.card_bg).pack(anchor=tk.W)
                
        tk.Label(content_frame,
                text=f"Subject: {subject}",
                font=self.text_font,
                fg=self.text_color,
                bg=self.card_bg).pack(anchor=tk.W)
                
        tk.Label(content_frame,
                text=f"Date: {date}",
                font=self.text_font,
                fg=self.text_color,
                bg=self.card_bg).pack(anchor=tk.W)
                
        # Separator
        ttk.Separator(content_frame, orient='horizontal').pack(fill=tk.X, pady=10)
        
        # Message content
        msg_text = tk.Text(content_frame,
                          wrap=tk.WORD,
                          font=self.text_font,
                          bg=self.card_bg,
                          fg=self.text_color,
                          relief=tk.FLAT,
                          height=10)
        msg_text.pack(fill=tk.BOTH, expand=True)
        
        try:
            # Get message content using detail.php
            msg_response = self.session.get(
                f'https://anonmails.de/detail.php?uid={uid}',
                headers={
                    'Referer': 'https://anonmails.de/inbox.php',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                }
            )
            
            if msg_response.status_code == 200:
                msg_soup = BeautifulSoup(msg_response.text, 'html.parser')
                
                # Find the message content in the text-plain div
                content_div = msg_soup.find('div', class_='text-plain')
                if content_div:
                    # Get the content and preserve line breaks
                    content = content_div.get_text('\n', strip=True)
                    msg_text.delete(1.0, tk.END)
                    msg_text.insert(tk.END, content)
                else:
                    msg_text.insert(tk.END, "Could not find message content")
            else:
                msg_text.insert(tk.END, f"Failed to fetch message. Status: {msg_response.status_code}")
                
        except Exception as e:
            msg_text.delete(1.0, tk.END)
            msg_text.insert(tk.END, f"Error loading message: {str(e)}")
            print(f"Exception details: {str(e)}")
        
        msg_text.config(state=tk.DISABLED)

    def init_session(self):
        """Initialize a new session with proper headers and cookies"""
        self.session = requests.Session()
        
        # Set default headers
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.140 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Origin': 'https://anonmails.de',
            'Referer': 'https://anonmails.de/',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache'
        })
        
        try:
            # Visit main page to get initial cookies
            main_response = self.session.get('https://anonmails.de/')
            if main_response.status_code != 200:
                print(f"Warning: Failed to get main page. Status code: {main_response.status_code}")
            
        except Exception as e:
            print(f"Failed to initialize session: {e}")

    def generate_random_credentials(self):
        # Generate random username (15-20 characters)
        username = ''.join(random.choices(string.ascii_letters + string.digits, k=random.randint(15, 20)))
        # Generate random password (12-16 characters)
        password = ''.join(random.choices(string.ascii_letters + string.digits, k=random.randint(12, 16)))
        return username, password

    def generate_email(self):
        try:
            # Reinitialize session
            self.init_session()
            
            username, password = self.generate_random_credentials()
            email = f"{username}@anonmails.de"
            
            # Registration data
            data = {
                'emailAddr': username,
                'emailPass': password,
                'emailPassConfirm': password,
                'emailExpire': self.lifespan_var.get(),  # Use selected lifespan
                'method': 'add'
            }
            
            # Send registration request
            response = self.session.post(
                'https://anonmails.de/account-add.php',
                data=data,
                headers={
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            )
            
            if response.status_code == 200:
                response_data = response.json()
                if response_data.get('status') == 'OK':
                    self.current_email.set(f"Email: {email}")
                    self.password_var.set(f"Password: {password}")
                    self.email_password = password
                    self.add_to_history(email, password)
                    self.update_statistics()
                    messagebox.showinfo("Success", "Email generated successfully!")
                else:
                    messagebox.showerror("Error", f"Failed to generate email: {response_data.get('message', 'Unknown error')}")
            else:
                messagebox.showerror("Error", f"Failed to generate email. Status code: {response.status_code}")
                
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def check_inbox(self):
        if not self.current_email.get():
            messagebox.showwarning("Warning", "Please generate an email first!")
            return
            
        try:
            # Clear existing items
            for item in self.inbox_tree.get_children():
                self.inbox_tree.delete(item)
            
            # Get email without prefix
            email_addr = self.current_email.get().replace("Email: ", "").split('@')[0]
            
            # Login data
            login_data = {
                'emailAddr': email_addr,
                'emailPass': self.email_password
            }
            
            # Perform login and check inbox
            response = self.session.post(
                'https://anonmails.de/inbox.php',
                data=login_data
            )
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                inbox_table = soup.find('table', class_='inbox')
                
                if inbox_table:
                    rows = inbox_table.find_all('tr')[1:-1]  # Skip header row and total messages row
                    message_count = 0
                    for row in rows:
                        cols = row.find_all('td')
                        if len(cols) >= 6:
                            # Find the message link to get UID
                            msg_link = row.find('a', href=lambda x: x and 'detail.php?uid=' in x)
                            if msg_link:
                                uid = msg_link['href'].split('uid=')[1]
                                date = cols[1].text.strip()
                                sender = cols[2].text.strip()
                                subject = cols[3].text.strip()
                                
                                if sender and subject:
                                    # Store the UID as a value in the tree item
                                    self.inbox_tree.insert("", 0, values=(sender, subject, date, uid))
                                    message_count += 1
                
                    # Only update total messages if new messages are found
                    if message_count > 0:
                        self.stats["total_messages"] += message_count
                        self.total_messages_label.config(text=str(self.stats["total_messages"]))
                        self.save_statistics()
                    
                    if not self.inbox_tree.get_children():
                        messagebox.showinfo("Inbox", "No messages found.")
                else:
                    messagebox.showinfo("Inbox", "No messages found.")
            else:
                messagebox.showerror("Error", f"Failed to check inbox. Status code: {response.status_code}")
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to check inbox: {str(e)}")

    def copy_to_clipboard(self, text):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()
        messagebox.showinfo("Success", "Copied to clipboard!")

    def add_to_history(self, email, password):
        # Check if email already exists in history
        for item in self.email_history:
            if item["email"] == email:
                return
                
        self.email_history.append({"email": email, "password": password})
        self.update_history_dropdown()
        self.save_email_history()

    def load_email_history(self):
        try:
            home_dir = os.path.expanduser("~")
            history_file = os.path.join(home_dir, '.anonmail_history.json')
            
            if os.path.exists(history_file):
                with open(history_file, 'r') as f:
                    self.email_history = json.load(f)
                    if self.email_history:
                        last_email = self.email_history[-1]
                        self.current_email.set(f"Email: {last_email['email']}")
                        self.password_var.set(f"Password: {last_email['password']}")
                        self.email_password = last_email["password"]
                        # Update the history listbox immediately
                        self.update_history_dropdown()
        except Exception as e:
            print(f"Error loading email history: {e}")
            self.email_history = []

    def save_email_history(self):
        try:
            home_dir = os.path.expanduser("~")
            history_file = os.path.join(home_dir, '.anonmail_history.json')
            
            with open(history_file, 'w') as f:
                json.dump(self.email_history, f)
        except Exception as e:
            print(f"Error saving email history: {e}")

    def update_statistics(self):
        self.stats["total_emails"] = len(self.email_history)
        self.total_emails_label.config(text=str(self.stats["total_emails"]))
        self.save_statistics()

    def save_statistics(self):
        try:
            home_dir = os.path.expanduser("~")
            stats_file = os.path.join(home_dir, '.anonmail_stats.json')
            with open(stats_file, 'w') as f:
                json.dump(self.stats, f)
        except Exception as e:
            print(f"Error saving statistics: {e}")

    def load_statistics(self):
        try:
            home_dir = os.path.expanduser("~")
            stats_file = os.path.join(home_dir, '.anonmail_stats.json')
            if os.path.exists(stats_file):
                with open(stats_file, 'r') as f:
                    self.stats = json.load(f)
        except Exception as e:
            print(f"Error loading statistics: {e}")

    def run(self):
        self.root.mainloop()

    def new_identity(self):
        """Reset all statistics and clear email history"""
        if messagebox.askyesno("Confirm Reset", "Are you sure you want to reset everything? This will delete all email history and statistics."):
            # Clear email history
            self.email_history = []
            self.update_history_dropdown()
            self.save_email_history()
            
            # Reset statistics
            self.stats = {
                "total_emails": 0,
                "total_messages": 0,
                "platforms": {}
            }
            self.save_statistics()
            
            # Update UI
            self.current_email.set("Email: ")
            self.password_var.set("Password: ")
            self.email_password = ""
            self.total_emails_label.config(text="0")
            self.total_messages_label.config(text="0")
            
            # Clear inbox
            for item in self.inbox_tree.get_children():
                self.inbox_tree.delete(item)
            
            messagebox.showinfo("Success", "Identity reset complete")

if __name__ == "__main__":
    app = TempMailGenerator()
    app.run()